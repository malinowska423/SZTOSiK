CREATE PROCEDURE generuj_oceny_na_semestr(IN semestr_ char(4))
BLOCK1 : BEGIN
  DECLARE rok int;
  DECLARE kurs int;
  DECLARE sukces boolean DEFAULT TRUE;

  DECLARE psl char(11);
  DECLARE klasa char(4);
  DECLARE data_oceny date;
  DECLARE wartosc_oc varchar(2);
  DECLARE waga_oc int;

  DECLARE done int DEFAULT FALSE;
  DECLARE bad_data CONDITION FOR 30001;
  DECLARE index_uczen_klasa CURSOR FOR (SELECT id_ucznia,id_klasy FROM klasa_uczniowie);
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
  DECLARE CONTINUE HANDLER FOR bad_data SET sukces = FALSE;
  OPEN index_uczen_klasa;
  read_loop:
    LOOP
      FETCH index_uczen_klasa INTO psl,klasa;
      IF done THEN
        SET @psl = psl;
        LEAVE read_loop;
      END IF;
      SET rok = cast(substring(semestr_, 1, 2) AS int);
      IF rok >= cast(substring(klasa, 1, 2) AS int) THEN

        SET @a = rok;

        BLOCK2 : BEGIN
          DECLARE liczba_ocen int;
          DECLARE k int;
          DECLARE done2 int DEFAULT FALSE;
          DECLARE index_kurs CURSOR FOR
            (SELECT DISTINCT id_kursu FROM zajecia JOIN klasa_uczniowie ON zajecia.id_klasy = klasa_uczniowie.id_klasy WHERE id_ucznia LIKE psl AND semestr LIKE semestr_);
          DECLARE CONTINUE HANDLER FOR NOT FOUND SET done2 = 1;
          SET @e = klasa;
          OPEN index_kurs;
          loop_2:
            LOOP
              FETCH index_kurs INTO kurs;
              IF done2 THEN
                SET @f = psl;
                LEAVE loop_2;
              END IF;

              SET @b = 20000;
              SET k = 0;
              SET liczba_ocen = floor(rand()*5) + 5;
              WHILE k < liczba_ocen DO
                SET sukces = FALSE;
                WHILE sukces = FALSE DO
                  SET sukces = TRUE;
                  SET wartosc_oc = elt(floor(rand()*14)+1, '1', '2-', '2', '2+', '3-', '3', '3+', '4-', '4', '4+', '5-', '5', '5+', '6');
                  SET waga_oc = elt(floor(rand()*5)+1, 1,2,3,4,5);
                  IF substring(semestr_,4,1) = '1' THEN
                    SET data_oceny = losowa_data_miedzy(concat('20',rok, '-09-01'), concat('20', rok+1, '-01-30'));
                    SET @c = data_oceny;
                  ELSE
                    SET data_oceny = losowa_data_miedzy(concat('20',rok,'-02-01'), concat('20',rok,'-06-30'));
                  END IF;
                  INSERT INTO oceny (id_ucznia, id_kursu, data, semestr, typ, wartosc, waga, opis)
                  VALUES (psl, kurs, data_oceny, semestr_, 'cząstkowa', wartosc_oc, waga_oc, elt(waga_oc, 'praca domowa', 'odpowiedź', 'kartkówka', 'test', 'sprawdzian'));
                  IF sukces = TRUE THEN
                    SET @d = 15;
                    SET k = k + 1;
                  END IF;
                END WHILE ;
              END WHILE;

            END LOOP;
        END BLOCK2;
      END IF ;
    END LOOP;
  CLOSE index_uczen_klasa;
END BLOCK1;

