create procedure uzytkownicy_uczniowie()
BEGIN
  DECLARE psl char(11);
  DECLARE klasa char(4);
  DECLARE sukces boolean DEFAULT TRUE;
  DECLARE done INT DEFAULT FALSE;
  DECLARE bad_data CONDITION FOR 30001;
  DECLARE index_uczen CURSOR FOR (SELECT pesel FROM uczniowie);
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
  DECLARE CONTINUE HANDLER FOR bad_data SET sukces = FALSE;
  OPEN index_uczen;
  read_loop:
    LOOP
      FETCH index_uczen INTO psl;
      IF done THEN
        LEAVE read_loop;
      END IF;
      set @stm = concat('create user \'', psl, '\'@\'sql.amalinowska.nazwa.pl\';');
      prepare creuse from @stm;
      execute creuse;
      set @stm = concat('set password for \'', psl, '\'@\'sql.amalinowska.nazwa.pl\' = password(\'uczen1\');');
      prepare creuse from @stm;
      execute creuse;
      set @stm = concat('grant select on amalinowska_sztosik.zajecia to\'', psl, '\'@\'sql.amalinowska.nazwa.pl\';');
      prepare creuse from @stm;
      execute creuse;
    END LOOP;
  CLOSE index_uczen;
END;

