CREATE FUNCTION ocena_semestralna(ocena double) RETURNS varchar(2)
BEGIN
  IF ocena BETWEEN 0 AND 1.8 THEN
    RETURN '1';
  END IF;
  IF ocena < 2 THEN
    RETURN '2-';
  END IF;
  IF ocena < 2.5 THEN
    RETURN '2';
  END IF;
  IF ocena < 2.75 THEN
    RETURN '2+';
  END IF;
  IF ocena < 3.0 THEN
    RETURN '3-';
  END IF;
  IF ocena < 3.5 THEN
    RETURN '3';
  END IF;
  IF ocena < 3.75 THEN
    RETURN '3+';
  END IF;
  IF ocena < 4.0 THEN
    RETURN '4-';
  END IF;
  IF ocena < 4.5 THEN
    RETURN '4';
  END IF;
  IF ocena < 4.75 THEN
    RETURN '4+';
  END IF;
  IF ocena < 5.0 THEN
    RETURN '5-';
  END IF;
  IF ocena < 5.5 THEN
    RETURN '5';
  END IF;
  IF ocena < 5.9 THEN
    RETURN '5+';
  END IF;
  IF ocena <= 6.0 THEN
    RETURN '6';
  END IF;
END;

