create function losowa_data_urodzin(wiek int) returns date
BEGIN
  DECLARE data date;
  SET data = date_sub(curdate(), INTERVAL (wiek*365 - floor(rand()*365)) DAY );
  RETURN data;
END;

