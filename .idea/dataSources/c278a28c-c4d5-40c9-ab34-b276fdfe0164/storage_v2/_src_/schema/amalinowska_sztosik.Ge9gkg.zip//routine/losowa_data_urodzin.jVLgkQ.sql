CREATE FUNCTION losowa_data_urodzin(wiek int) RETURNS date
BEGIN
  DECLARE data date;
  SET data = date_sub(curdate(), INTERVAL (wiek*365 - floor(rand()*365)) DAY );
  RETURN data;
END;

