create trigger zajecia_insert
  before INSERT
  on zajecia
  for each row
BEGIN
    IF (SELECT count(id_zajec) FROM zajecia WHERE semestr = NEW.semestr
                                AND dzien_tygodnia = NEW.dzien_tygodnia
                                AND nr_lekcji = NEW.nr_lekcji
                                AND (id_klasy = NEW.id_klasy OR id_sali = NEW.id_sali OR id_kursu = NEW.id_kursu)) > 0 THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Zajęcia w tym czasie już istnieją';
    END IF;
  END;

