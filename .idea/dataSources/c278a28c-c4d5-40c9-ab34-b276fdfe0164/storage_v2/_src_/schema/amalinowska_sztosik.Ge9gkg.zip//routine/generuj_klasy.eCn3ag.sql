create procedure generuj_klasy()
BEGIN
	DECLARE i int DEFAULT 1;
	DECLARE rocznik int DEFAULT year(curdate()) - 8 - 2000;
	DECLARE kod int DEFAULT 1;

	DECLARE bad_data CONDITION FOR 30001;
	DECLARE CONTINUE HANDLER FOR bad_data
	  BEGIN
			SET i = i - 1;
			SET kod = kod - 1;
		END;

	WHILE i <= 24 DO
		INSERT INTO klasy (id_klasy, liczebnosc, wychowawca, sala)
		VALUES (CONCAT(rocznik,'/', elt(kod, 'A', 'B', 'C')),
		        0,
            (SELECT pesel FROM nauczyciele ORDER BY rand() LIMIT 1),
            (SELECT nr_sali FROM sale ORDER BY rand() LIMIT 1));
		SET i = i + 1;
	  SET kod = kod + 1;
	  IF kod = 4 THEN
      SET kod = 1;
      SET rocznik = rocznik + 1;
    END IF;
	END WHILE ;
END;

