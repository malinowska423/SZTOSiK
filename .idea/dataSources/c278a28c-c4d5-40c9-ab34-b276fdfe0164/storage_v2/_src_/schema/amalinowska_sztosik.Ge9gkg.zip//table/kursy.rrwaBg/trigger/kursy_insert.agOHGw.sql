CREATE TRIGGER kursy_insert
  BEFORE INSERT
  ON kursy
  FOR EACH ROW
BEGIN
    IF (SELECT id_kursu FROM kursy WHERE id_nauczyciela = NEW.id_nauczyciela AND id_przedmiotu = NEW.id_przedmiotu) IS NOT NULL THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Taki kurs już istnieje';
    END IF;
    IF (SELECT count(id_przedmiotu) FROM kursy WHERE id_nauczyciela = NEW.id_nauczyciela) > 2 THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Zbyt wiele kursów tego nauczyciela';
    END IF;
    IF (SELECT count(id_nauczyciela) FROM kursy WHERE id_przedmiotu = NEW.id_przedmiotu) > 3 THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Zbyt wiele kursów tego przedmiotu';
    END IF;
  END;

