create trigger ku_update
  after UPDATE
  on klasa_uczniowie
  for each row
BEGIN
    UPDATE klasy SET liczebnosc = liczebnosc + 1 WHERE id_klasy = NEW.id_klasy;
    UPDATE klasy SET liczebnosc = liczebnosc - 1 WHERE id_klasy = OLD.id_klasy;
  END;

