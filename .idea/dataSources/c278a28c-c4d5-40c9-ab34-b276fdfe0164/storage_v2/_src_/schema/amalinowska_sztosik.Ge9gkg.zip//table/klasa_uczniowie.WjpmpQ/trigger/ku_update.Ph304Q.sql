CREATE TRIGGER ku_update
  AFTER UPDATE
  ON klasa_uczniowie
  FOR EACH ROW
BEGIN
    UPDATE klasy SET liczebnosc = liczebnosc + 1 WHERE id_klasy = NEW.id_klasy;
    UPDATE klasy SET liczebnosc = liczebnosc - 1 WHERE id_klasy = OLD.id_klasy;
  END;

