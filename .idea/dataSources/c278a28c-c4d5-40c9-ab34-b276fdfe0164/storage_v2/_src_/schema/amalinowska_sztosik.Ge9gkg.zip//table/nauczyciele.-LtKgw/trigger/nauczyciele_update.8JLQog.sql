CREATE TRIGGER nauczyciele_update
  BEFORE UPDATE
  ON nauczyciele
  FOR EACH ROW
BEGIN
    SET @newpsl = NEW.pesel;
#     weryfikacja numeru pesel
    IF (((CAST(SUBSTRING(@newpsl,1,1) AS int))
			+(CAST(SUBSTRING(@newpsl,2,1) AS int)*3)
			+(CAST(SUBSTRING(@newpsl,3,1) AS int)*7)
			+(CAST(SUBSTRING(@newpsl,4,1) AS int)*9)
			+(CAST(SUBSTRING(@newpsl,5,1) AS int))
			+(CAST(SUBSTRING(@newpsl,6,1) AS int)*3)
			+(CAST(SUBSTRING(@newpsl,7,1) AS int)*7)
			+(CAST(SUBSTRING(@newpsl,8,1) AS int)*9)
			+(CAST(SUBSTRING(@newpsl,9,1) AS int))
			+(CAST(SUBSTRING(@newpsl,10,1) AS int)*3)
			+(CAST(SUBSTRING(@newpsl,11,1) AS int)))%10 <> 0)
	     OR ( @newpsl <> OLD.pesel AND @newpsl IN (SELECT pesel FROM nauczyciele)) THEN
		    SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Nieprawidlowy numer PESEL';
	  END IF;
# 	  weryfikacja daty urodzenia z peselem
    IF (cast(substring(@newpsl,1,2) AS int) <> year(NEW.data_urodzenia)-1900
      OR cast(substring(@newpsl,3,2) AS int) <> month(NEW.data_urodzenia)
      OR cast(substring(@newpsl,5,2) AS int) <> day(NEW.data_urodzenia)) THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Nieprawidlowa data urodzenia lub PESEL';
    END IF;
#     weryfikacja numeru telefonu
    IF NEW.nr_kontaktowy < 100000000 OR NEW.nr_kontaktowy > 999999999 THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Nieprawidlowy numer telefonu';
    END IF;
  END;

