create trigger nauczyciele_before_delete
  before DELETE
  on nauczyciele
  for each row
BEGIN
    IF OLD.pesel IN (SELECT wychowawca FROM klasy) THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Ten nauczyciel jest wychowawcą którejś klasy. Zmień najpierw wychowawcę.';
    END IF;

    DELETE FROM kursy WHERE id_nauczyciela = OLD.pesel;
  END;

