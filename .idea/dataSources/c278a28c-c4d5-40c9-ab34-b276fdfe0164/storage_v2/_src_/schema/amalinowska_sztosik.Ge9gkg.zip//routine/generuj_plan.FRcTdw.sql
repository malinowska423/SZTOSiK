create procedure generuj_plan()
BEGIN
  DECLARE dzien int DEFAULT 1;
  DECLARE lekcja int DEFAULT 0;
  DECLARE rok int;
  DECLARE semestr_ int DEFAULT 1;
  DECLARE kurs int;
  DECLARE sala int;
	DECLARE klasa char(4);
	DECLARE max_lekcji int;
	DECLARE sukces boolean DEFAULT TRUE;
	DECLARE done INT DEFAULT FALSE;
  DECLARE bad_data CONDITION FOR 30001;
  DECLARE index_klasa CURSOR FOR (SELECT id_klasy FROM klasy);
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	DECLARE CONTINUE HANDLER FOR bad_data SET sukces = FALSE;
  OPEN index_klasa;
    read_loop: LOOP
      FETCH index_klasa INTO klasa;
      IF done THEN
        LEAVE read_loop;
      END IF;
      SET rok = cast(substring(klasa,1,2) AS int);
      SET semestr_ = 1;
      WHILE rok < 19 DO
        SET dzien = 1;
        WHILE dzien < 6 DO
          SET lekcja = 1;
          SET max_lekcji = floor(rand()*3)+5;
          WHILE lekcja <= max_lekcji DO
            SET sukces = FALSE;
            WHILE sukces = FALSE DO
              SET sukces = TRUE;
              SET kurs = (SELECT id_kursu FROM kursy ORDER BY rand() LIMIT 1);
              SET sala = (SELECT nr_sali FROM sale ORDER BY rand() LIMIT 1);
              INSERT INTO zajecia (id_kursu, id_klasy, id_sali, nr_lekcji, dzien_tygodnia, semestr)
              VALUES (kurs, klasa, sala, lekcja, elt(dzien, 'pon', 'wt', 'śr', 'czw', 'pt'), concat(rok, '/', semestr_));
              IF sukces = TRUE THEN
                SET lekcja = lekcja + 1;
              END IF;
            END WHILE ;
          END WHILE;
          SET dzien = dzien + 1;
        END WHILE;
        IF semestr_ = 1 THEN
          SET semestr_ = 2;
          SET rok = rok + 1;
          ELSE
          SET semestr_ = 1;
        END IF;
      END WHILE;
    END LOOP;
  CLOSE index_klasa;
END;

