create trigger sale_insert
  before INSERT
  on sale
  for each row
BEGIN
    IF NEW.pojemnosc < 15 THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Zbyt mała pojemność sali';
    END IF;
  END;

