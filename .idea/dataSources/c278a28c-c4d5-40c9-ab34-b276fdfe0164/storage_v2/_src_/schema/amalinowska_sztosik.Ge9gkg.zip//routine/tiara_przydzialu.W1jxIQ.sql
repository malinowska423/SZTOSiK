CREATE PROCEDURE tiara_przydzialu()
BEGIN
	DECLARE psl char(11);
	DECLARE klasa char(4);
	DECLARE sukces boolean DEFAULT TRUE;
	DECLARE done INT DEFAULT FALSE;
  DECLARE bad_data CONDITION FOR 30001;
  DECLARE index_uczen CURSOR FOR (SELECT pesel FROM uczniowie);
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	DECLARE CONTINUE HANDLER FOR bad_data SET sukces = FALSE;
  OPEN index_uczen;
    read_loop: LOOP
      FETCH index_uczen INTO psl;
      IF done THEN
        LEAVE read_loop;
      END IF;
      SET sukces = FALSE;
      WHILE sukces = FALSE DO
        SET sukces = TRUE;
      SET klasa = concat(cast(substring(psl,1,2) AS int) + 6, '/', elt(floor(rand()*3) + 1, 'A', 'B', 'C'));
        INSERT INTO klasa_uczniowie (id_klasy, id_ucznia) VALUES (klasa, psl);
      END WHILE ;
    END LOOP;
  CLOSE index_uczen;
END;

