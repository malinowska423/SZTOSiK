create trigger kursy_delete
  before DELETE
  on kursy
  for each row
BEGIN 
    DELETE FROM oceny WHERE id_kursu = OLD.id_kursu;
  END;

