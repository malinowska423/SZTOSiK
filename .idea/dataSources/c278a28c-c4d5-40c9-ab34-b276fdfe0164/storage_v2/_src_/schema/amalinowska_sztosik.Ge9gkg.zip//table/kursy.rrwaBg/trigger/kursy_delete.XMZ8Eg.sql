CREATE TRIGGER kursy_delete
  BEFORE DELETE
  ON kursy
  FOR EACH ROW
BEGIN 
    DELETE FROM oceny WHERE id_kursu = OLD.id_kursu;
  END;

