create trigger uczniowie_delete
  before DELETE
  on uczniowie
  for each row
BEGIN
    SET @id_klasy = (SELECT id_klasy FROM klasa_uczniowie WHERE id_ucznia = OLD.pesel);



      DELETE FROM oceny WHERE OLD.pesel = id_ucznia;
      DELETE FROM klasa_uczniowie WHERE id_ucznia = OLD.pesel;

  END;

