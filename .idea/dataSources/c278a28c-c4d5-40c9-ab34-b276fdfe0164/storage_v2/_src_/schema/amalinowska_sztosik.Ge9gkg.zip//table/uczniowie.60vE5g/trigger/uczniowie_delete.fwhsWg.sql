create trigger uczniowie_delete
  before DELETE
  on uczniowie
  for each row
BEGIN
    SET @id_klasy = (SELECT id_klasy FROM klasa_uczniowie WHERE id_ucznia = OLD.pesel);
#     SET AUTOCOMMIT = 0;
#     START TRANSACTION;
#       UPDATE klasy SET liczebnosc = liczebnosc - 1 WHERE id_klasy = @id_klasy;
      DELETE FROM oceny WHERE OLD.pesel = id_ucznia;
      DELETE FROM klasa_uczniowie WHERE id_ucznia = OLD.pesel;
#     COMMIT;
  END;

