create trigger oceny_insert
  before INSERT
  on oceny
  for each row
BEGIN
    IF NEW.data > now() THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Ocena nie może zostać dodana w przyszłości';
    END IF;
    IF NEW.waga < 0 OR NEW.waga > 5 THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Nieprawidłowa waga oceny';
    END IF;
  END;

