create function losowa_data_miedzy(fromDate date, toDate date) returns date
BEGIN
  DECLARE days_between INT;
  DECLARE days_rand INT;

  SET days_between = datediff(toDate, fromDate);
  SET days_rand = cast(RAND() * 10000 AS int) % days_between;
  RETURN date_add(fromDate, INTERVAL days_rand DAY );
END;

