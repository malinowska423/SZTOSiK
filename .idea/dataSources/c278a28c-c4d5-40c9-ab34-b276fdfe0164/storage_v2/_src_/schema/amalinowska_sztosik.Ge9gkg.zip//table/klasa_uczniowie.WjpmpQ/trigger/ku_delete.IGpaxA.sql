create trigger ku_delete
  before DELETE
  on klasa_uczniowie
  for each row
BEGIN
    IF (SELECT liczebnosc FROM klasy WHERE klasy.id_klasy = OLD.id_klasy) > 1 THEN 
      UPDATE klasy SET liczebnosc = liczebnosc - 1 WHERE id_klasy = OLD.id_klasy;
    END IF ;
#     IF (SELECT id_ucznia FROM klasa_uczniowie WHERE id_klasy = OLD.id_klasy) IS NULL THEN
#       DELETE FROM klasy WHERE klasy.id_klasy = OLD.id_klasy;
#     END IF;
  END;

