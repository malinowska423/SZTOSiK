CREATE TRIGGER ku_after_insert
  AFTER INSERT
  ON klasa_uczniowie
  FOR EACH ROW
  UPDATE klasy SET liczebnosc = liczebnosc + 1 WHERE id_klasy = NEW.id_klasy;

