create trigger ku_after_insert
  after INSERT
  on klasa_uczniowie
  for each row
  UPDATE klasy SET liczebnosc = liczebnosc + 1 WHERE id_klasy = NEW.id_klasy;

