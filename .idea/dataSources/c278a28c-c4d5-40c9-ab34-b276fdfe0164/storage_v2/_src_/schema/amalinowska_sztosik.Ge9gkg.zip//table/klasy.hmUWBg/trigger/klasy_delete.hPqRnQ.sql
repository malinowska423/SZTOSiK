create trigger klasy_delete
  before DELETE
  on klasy
  for each row
BEGIN
#     SET AUTOCOMMIT = 0;
#     START TRANSACTION ;

    DELETE FROM zajecia WHERE id_klasy = OLD.id_klasy;
    DELETE FROM klasa_uczniowie WHERE id_klasy = OLD.id_klasy;
#     COMMIT ;
  END;

