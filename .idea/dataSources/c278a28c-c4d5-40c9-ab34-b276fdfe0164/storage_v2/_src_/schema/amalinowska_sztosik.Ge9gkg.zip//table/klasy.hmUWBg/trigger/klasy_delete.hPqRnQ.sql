CREATE TRIGGER klasy_delete
  BEFORE DELETE
  ON klasy
  FOR EACH ROW
BEGIN
#     SET AUTOCOMMIT = 0;
#     START TRANSACTION ;

    DELETE FROM zajecia WHERE id_klasy = OLD.id_klasy;
    DELETE FROM klasa_uczniowie WHERE id_klasy = OLD.id_klasy;
#     COMMIT ;
  END;

