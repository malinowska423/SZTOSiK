CREATE TRIGGER sale_update
  BEFORE UPDATE
  ON sale
  FOR EACH ROW
BEGIN
    IF NEW.pojemnosc < 15
      OR NEW.pojemnosc < (SELECT MAX(liczebnosc) FROM zajecia JOIN klasy k ON zajecia.id_klasy = k.id_klasy WHERE id_sali = NEW.nr_sali)
      THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Zbyt mała pojemność sali';
    END IF;
  END;

