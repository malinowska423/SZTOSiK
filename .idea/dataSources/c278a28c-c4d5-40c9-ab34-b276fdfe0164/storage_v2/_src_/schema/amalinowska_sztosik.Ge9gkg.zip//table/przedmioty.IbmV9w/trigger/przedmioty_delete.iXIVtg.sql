create trigger przedmioty_delete
  after DELETE
  on przedmioty
  for each row
  DELETE FROM kursy WHERE kursy.id_przedmiotu LIKE OLD.id_przedmiotu;

