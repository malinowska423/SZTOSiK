CREATE TRIGGER przedmioty_delete
  AFTER DELETE
  ON przedmioty
  FOR EACH ROW
  DELETE FROM kursy WHERE kursy.id_przedmiotu LIKE OLD.id_przedmiotu;

