create function ocena_roczna(ocena double) returns varchar(2)
BEGIN
  IF ocena BETWEEN 0 AND 1.99999 THEN
    RETURN '1';
  END IF;
  IF ocena < 2.5 THEN
    RETURN '2';
  END IF;
  IF ocena < 3.5 THEN
    RETURN '3';
  END IF;
  IF ocena < 4.5 THEN
    RETURN '4';
  END IF;
  IF ocena < 5.8 THEN
    RETURN '5';
  END IF;
  IF ocena <= 6.0 THEN
    RETURN '6';
  END IF;
END;

