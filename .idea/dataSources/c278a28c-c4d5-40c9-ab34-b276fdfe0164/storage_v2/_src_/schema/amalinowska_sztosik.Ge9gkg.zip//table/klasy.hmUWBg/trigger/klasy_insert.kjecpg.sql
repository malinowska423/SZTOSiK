CREATE TRIGGER klasy_insert
  BEFORE INSERT
  ON klasy
  FOR EACH ROW
BEGIN
    IF NEW.liczebnosc > 36 OR NEW.liczebnosc < 0 THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Nieprawidłowa liczba osób w klasie';
    END IF;
    IF NEW.wychowawca IN (SELECT wychowawca FROM klasy) THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Ten nauczyciel jest już wychowawcą';
    END IF;
    IF NEW.sala IN (SELECT sala FROM klasy) THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Ta sala jest już przypisana do innej klasy';
    END IF;
    IF NEW.liczebnosc > (SELECT pojemnosc FROM sale WHERE nr_sali = NEW.sala) THEN 
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Sala zbyt mala dla takiej liczby osob';
    END IF;
  END;

