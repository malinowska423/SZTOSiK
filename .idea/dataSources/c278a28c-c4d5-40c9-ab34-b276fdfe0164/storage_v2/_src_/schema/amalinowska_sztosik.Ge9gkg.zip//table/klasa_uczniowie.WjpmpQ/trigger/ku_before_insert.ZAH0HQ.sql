create trigger ku_before_insert
  before INSERT
  on klasa_uczniowie
  for each row
BEGIN
    IF NEW.id_ucznia IN (SELECT id_ucznia FROM klasa_uczniowie) THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Ten uczeń należy już do jakiejś klasy';
    END IF;
  END;

