create trigger dzwonki_update
  before UPDATE
  on dzwonki
  for each row
BEGIN
    IF NEW.nr_lekcji > 10 THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Zbyt duży numer lekcji';
    END IF;
    IF (SELECT count(nr_lekcji) FROM dzwonki) > 10 THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Zbyt wiele lekcji';
    END IF;
    IF timediff(NEW.koniec, NEW.poczatek) < '00:45:00' THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Zbyt krótka lekcja';
    END IF;
    IF NEW.nr_lekcji > 1 AND timediff(NEW.poczatek, (SELECT koniec FROM dzwonki WHERE nr_lekcji = NEW.nr_lekcji - 1)) < '00:05:00' THEN
      SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO=30001, MESSAGE_TEXT='Zbyt krotka przerwa';
    END IF;

  END;

