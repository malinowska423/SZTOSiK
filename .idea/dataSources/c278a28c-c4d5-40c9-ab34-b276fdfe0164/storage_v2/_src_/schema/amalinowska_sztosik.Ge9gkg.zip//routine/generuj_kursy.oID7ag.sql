create procedure generuj_kursy()
BEGIN
	DECLARE i int DEFAULT 1;

	DECLARE bad_data CONDITION FOR 30001;
	DECLARE CONTINUE HANDLER FOR bad_data SET i = i - 1;

	WHILE i <= 48 DO
		INSERT INTO kursy (id_nauczyciela, id_przedmiotu)
		VALUES ((SELECT pesel FROM nauczyciele ORDER BY rand() LIMIT 1),
            (SELECT id_przedmiotu FROM przedmioty ORDER BY rand() LIMIT 1));
		SET i = i + 1;
	END WHILE ;
END;

